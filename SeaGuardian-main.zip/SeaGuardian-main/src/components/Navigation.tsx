import React from 'react';
import { 
  Map, 
  AlertTriangle, 
  Fish, 
  Settings, 
  Radio,
  Shield,
  BarChart3
} from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  alertCount: number;
}

export default function Navigation({ activeTab, onTabChange, alertCount }: NavigationProps) {
  const navItems = [
    { id: 'map', label: 'Live Map', icon: Map },
    { id: 'alerts', label: 'Alerts', icon: AlertTriangle, badge: alertCount },
    { id: 'catches', label: 'Catch Log', icon: Fish },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'comms', label: 'Comms', icon: Radio },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="bg-slate-900 text-white w-64 min-h-screen p-4">
      <div className="flex items-center mb-8">
        <Shield className="h-8 w-8 text-teal-400 mr-3" />
        <div>
          <h1 className="text-xl font-bold">SeaGuardian</h1>
          <p className="text-sm text-slate-400">Maritime Safety</p>
        </div>
      </div>
      
      <nav className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center px-3 py-2 rounded-lg transition-colors ${
                activeTab === item.id
                  ? 'bg-teal-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Icon className="h-5 w-5 mr-3" />
              <span className="flex-1 text-left">{item.label}</span>
              {item.badge && item.badge > 0 && (
                <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>
      
      <div className="mt-8 p-4 bg-slate-800 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-slate-400">Connection Status</span>
          <div className="h-2 w-2 bg-green-400 rounded-full animate-pulse"></div>
        </div>
        <div className="text-xs text-slate-300">
          4G Active • LoRa Mesh Ready
        </div>
      </div>
    </div>
  );
}