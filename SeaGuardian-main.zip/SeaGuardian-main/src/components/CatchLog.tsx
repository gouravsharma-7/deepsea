import React, { useState } from 'react';
import { 
  Fish, 
  Camera, 
  MapPin, 
  Calendar, 
  Scale,
  AlertTriangle,
  Plus,
  Download
} from 'lucide-react';
import type { CatchLog as CatchLogType } from '../types';

interface CatchLogProps {
  catches: CatchLogType[];
  onAddCatch: (catchData: Omit<CatchLogType, 'id'>) => void;
}

const SPECIES_OPTIONS = [
  'Tuna (Yellowfin)',
  'Tuna (Skipjack)',
  'Marlin (Blue)',
  'Marlin (Black)',
  'Mahi Mahi',
  'Wahoo',
  'Kingfish',
  'Sailfish',
  'Shark (Hammerhead)',
  'Shark (Tiger)',
  'Other'
];

export default function CatchLog({ catches, onAddCatch }: CatchLogProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    vesselId: 'vessel-001',
    species: '',
    weight: '',
    bycatch: false,
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.species || !formData.weight) return;

    const newCatch: Omit<CatchLogType, 'id'> = {
      vesselId: formData.vesselId,
      species: formData.species,
      weight: parseFloat(formData.weight),
      timestamp: new Date().toISOString(),
      position: {
        lat: 15.2993 + (Math.random() - 0.5) * 0.1,
        lon: 74.1240 + (Math.random() - 0.5) * 0.1,
      },
      bycatch: formData.bycatch
    };

    onAddCatch(newCatch);
    setFormData({
      vesselId: 'vessel-001',
      species: '',
      weight: '',
      bycatch: false,
      notes: ''
    });
    setShowAddForm(false);
  };

  const totalWeight = catches.reduce((sum, catch_) => sum + catch_.weight, 0);
  const bycatchCount = catches.filter(catch_ => catch_.bycatch).length;
  const todaysCatches = catches.filter(catch_ => 
    new Date(catch_.timestamp).toDateString() === new Date().toDateString()
  );

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-900">Catch Log</h2>
          <div className="flex gap-3">
            <button className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded flex items-center">
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </button>
            <button 
              onClick={() => setShowAddForm(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded flex items-center"
            >
              <Plus className="h-4 w-4 mr-2" />
              Log Catch
            </button>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center">
              <Fish className="h-8 w-8 text-blue-500 mr-3" />
              <div>
                <p className="text-sm text-slate-600">Today's Catch</p>
                <p className="text-2xl font-bold text-slate-900">{todaysCatches.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center">
              <Scale className="h-8 w-8 text-green-500 mr-3" />
              <div>
                <p className="text-sm text-slate-600">Total Weight</p>
                <p className="text-2xl font-bold text-slate-900">{totalWeight.toFixed(1)} kg</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center">
              <AlertTriangle className="h-8 w-8 text-orange-500 mr-3" />
              <div>
                <p className="text-sm text-slate-600">Bycatch</p>
                <p className="text-2xl font-bold text-slate-900">{bycatchCount}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-purple-500 mr-3" />
              <div>
                <p className="text-sm text-slate-600">Total Trips</p>
                <p className="text-2xl font-bold text-slate-900">{Math.ceil(catches.length / 5)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Add Catch Form */}
        {showAddForm && (
          <div className="bg-white p-6 rounded-lg shadow-lg mb-8 border-l-4 border-blue-500">
            <h3 className="text-lg font-semibold mb-4">Log New Catch</h3>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Species *
                </label>
                <select
                  value={formData.species}
                  onChange={(e) => setFormData({ ...formData, species: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  required
                >
                  <option value="">Select species...</option>
                  {SPECIES_OPTIONS.map(species => (
                    <option key={species} value={species}>{species}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Weight (kg) *
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter weight"
                  required
                />
              </div>
              
              <div className="md:col-span-2">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.bycatch}
                    onChange={(e) => setFormData({ ...formData, bycatch: e.target.checked })}
                    className="w-4 h-4 text-orange-600 bg-gray-100 border-gray-300 rounded focus:ring-orange-500"
                  />
                  <span className="ml-2 text-sm font-medium text-slate-700">
                    Mark as Bycatch (unintended catch)
                  </span>
                </label>
              </div>
              
              <div className="md:col-span-2 flex gap-3">
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded font-medium"
                >
                  Log Catch
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded font-medium"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Catch List */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h3 className="text-lg font-semibold">Recent Catches</h3>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Species
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Weight
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Position
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {catches.slice().reverse().map((catch_, index) => (
                  <tr key={catch_.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                        {new Date(catch_.timestamp).toLocaleString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Fish className="h-4 w-4 text-blue-500 mr-2" />
                        <span className="text-sm font-medium text-gray-900">{catch_.species}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center">
                        <Scale className="h-4 w-4 text-green-500 mr-2" />
                        {catch_.weight} kg
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 text-red-500 mr-2" />
                        <span className="font-mono">
                          {catch_.position.lat.toFixed(4)}°N, {catch_.position.lon.toFixed(4)}°E
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {catch_.bycatch ? (
                        <span className="px-3 py-1 text-xs font-medium bg-orange-100 text-orange-800 rounded-full">
                          Bycatch
                        </span>
                      ) : (
                        <span className="px-3 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                          Target
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {catches.length === 0 && (
              <div className="text-center py-12">
                <Fish className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No catches logged yet</p>
                <button 
                  onClick={() => setShowAddForm(true)}
                  className="mt-2 text-blue-600 hover:text-blue-700 font-medium"
                >
                  Log your first catch
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}