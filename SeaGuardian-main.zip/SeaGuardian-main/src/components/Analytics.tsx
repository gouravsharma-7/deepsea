import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Fish, 
  MapPin, 
  Calendar,
  Award,
  AlertTriangle
} from 'lucide-react';
import type { CatchLog } from '../types';

interface AnalyticsProps {
  catches: CatchLog[];
}

export default function Analytics({ catches }: AnalyticsProps) {
  // Calculate analytics
  const totalCatches = catches.length;
  const totalWeight = catches.reduce((sum, catch_) => sum + catch_.weight, 0);
  const bycatchRate = (catches.filter(c => c.bycatch).length / totalCatches * 100) || 0;
  
  const speciesStats = catches.reduce((acc, catch_) => {
    acc[catch_.species] = (acc[catch_.species] || 0) + catch_.weight;
    return acc;
  }, {} as Record<string, number>);

  const topSpecies = Object.entries(speciesStats)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 5);

  // Monthly trend (mock data for demo)
  const monthlyData = [
    { month: 'Jan', catches: 45, weight: 892 },
    { month: 'Feb', catches: 52, weight: 1045 },
    { month: 'Mar', catches: 38, weight: 756 },
    { month: 'Apr', catches: 61, weight: 1234 },
    { month: 'May', catches: 48, weight: 967 },
    { month: 'Jun', catches: 55, weight: 1122 }
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Fleet Analytics</h2>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Catches</p>
                <p className="text-3xl font-bold text-slate-900">{totalCatches}</p>
                <p className="text-sm text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  +12% vs last month
                </p>
              </div>
              <Fish className="h-10 w-10 text-blue-500" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Weight</p>
                <p className="text-3xl font-bold text-slate-900">{totalWeight.toFixed(0)}<span className="text-lg">kg</span></p>
                <p className="text-sm text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  +8% vs last month
                </p>
              </div>
              <BarChart3 className="h-10 w-10 text-green-500" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Bycatch Rate</p>
                <p className="text-3xl font-bold text-slate-900">{bycatchRate.toFixed(1)}<span className="text-lg">%</span></p>
                <p className="text-sm text-red-600 flex items-center mt-1">
                  <AlertTriangle className="h-4 w-4 mr-1" />
                  Target: &lt;5%
                </p>
              </div>
              <AlertTriangle className="h-10 w-10 text-orange-500" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Sustainability Score</p>
                <p className="text-3xl font-bold text-slate-900">8.7<span className="text-lg">/10</span></p>
                <p className="text-sm text-green-600 flex items-center mt-1">
                  <Award className="h-4 w-4 mr-1" />
                  Excellent
                </p>
              </div>
              <Award className="h-10 w-10 text-purple-500" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Monthly Trends Chart */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-blue-500" />
              Monthly Catch Trends
            </h3>
            <div className="h-64 flex items-end justify-between space-x-2">
              {monthlyData.map((data, index) => {
                const maxCatches = Math.max(...monthlyData.map(d => d.catches));
                const height = (data.catches / maxCatches) * 200;
                return (
                  <div key={data.month} className="flex flex-col items-center">
                    <div className="text-xs text-slate-600 mb-2">{data.catches}</div>
                    <div 
                      className="w-8 bg-blue-500 rounded-t"
                      style={{ height: `${height}px` }}
                    ></div>
                    <div className="text-xs text-slate-600 mt-2">{data.month}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Top Species */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Fish className="h-5 w-5 mr-2 text-green-500" />
              Top Species by Weight
            </h3>
            <div className="space-y-4">
              {topSpecies.map(([species, weight], index) => {
                const percentage = (weight / totalWeight) * 100;
                return (
                  <div key={species} className="flex items-center">
                    <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 text-xs flex items-center justify-center font-semibold mr-3">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-slate-900">{species}</span>
                        <span className="text-sm text-slate-600">{weight.toFixed(1)} kg</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full"
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Fishing Zones Heatmap */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <MapPin className="h-5 w-5 mr-2 text-red-500" />
              Fishing Zones Activity
            </h3>
            <div className="grid grid-cols-6 gap-1">
              {Array.from({ length: 36 }, (_, i) => {
                const intensity = Math.random();
                const opacity = intensity * 0.8 + 0.1;
                return (
                  <div 
                    key={i}
                    className="aspect-square rounded-sm bg-blue-500"
                    style={{ opacity }}
                    title={`Zone ${i + 1}: ${(intensity * 100).toFixed(0)}% activity`}
                  ></div>
                );
              })}
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Heat map showing fishing activity across different zones (10km² grid)
            </p>
          </div>

          {/* Compliance Score */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Award className="h-5 w-5 mr-2 text-purple-500" />
              Compliance Metrics
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">EEZ Compliance</span>
                <div className="flex items-center">
                  <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                    <div className="bg-green-500 h-2 rounded-full w-full"></div>
                  </div>
                  <span className="text-sm font-semibold text-green-600">100%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">MPA Violations</span>
                <div className="flex items-center">
                  <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                    <div className="bg-green-500 h-2 rounded-full w-full"></div>
                  </div>
                  <span className="text-sm font-semibold text-green-600">0</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Quota Adherence</span>
                <div className="flex items-center">
                  <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                    <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '85%' }}></div>
                  </div>
                  <span className="text-sm font-semibold text-yellow-600">85%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Reporting Rate</span>
                <div className="flex items-center">
                  <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '92%' }}></div>
                  </div>
                  <span className="text-sm font-semibold text-green-600">92%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Environmental Impact */}
        <div className="mt-8 bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <MapPin className="h-5 w-5 mr-2 text-teal-500" />
            Environmental Impact Summary
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600 mb-1">2.1 tons</div>
              <div className="text-sm text-slate-600">CO₂ Saved vs Industry Avg</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600 mb-1">94%</div>
              <div className="text-sm text-slate-600">Sustainable Species Targeted</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600 mb-1">7</div>
              <div className="text-sm text-slate-600">Protected Areas Respected</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}