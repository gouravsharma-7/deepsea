import React from 'react';
import { 
  AlertTriangle, 
  Shield, 
  Cloud, 
  Fuel, 
  Wrench, 
  Users,
  Clock,
  CheckCircle2
} from 'lucide-react';
import type { Alert } from '../types';

interface AlertsPanelProps {
  alerts: Alert[];
  onAcknowledge: (alertId: string) => void;
}

export default function AlertsPanel({ alerts, onAcknowledge }: AlertsPanelProps) {
  const getAlertIcon = (type: Alert['type']) => {
    switch (type) {
      case 'SOS': return AlertTriangle;
      case 'GEOFENCE': return Shield;
      case 'WEATHER': return Cloud;
      case 'FUEL': return Fuel;
      case 'ENGINE': return Wrench;
      case 'MOB': return Users;
      default: return AlertTriangle;
    }
  };

  const getAlertColor = (severity: Alert['severity']) => {
    switch (severity) {
      case 'critical': return 'border-red-500 bg-red-50';
      case 'high': return 'border-orange-500 bg-orange-50';
      case 'medium': return 'border-yellow-500 bg-yellow-50';
      case 'low': return 'border-blue-500 bg-blue-50';
      default: return 'border-gray-500 bg-gray-50';
    }
  };

  const getAlertTextColor = (severity: Alert['severity']) => {
    switch (severity) {
      case 'critical': return 'text-red-800';
      case 'high': return 'text-orange-800';
      case 'medium': return 'text-yellow-800';
      case 'low': return 'text-blue-800';
      default: return 'text-gray-800';
    }
  };

  const getSeverityBadge = (severity: Alert['severity']) => {
    const colors = {
      critical: 'bg-red-500 text-white',
      high: 'bg-orange-500 text-white',
      medium: 'bg-yellow-500 text-white',
      low: 'bg-blue-500 text-white'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[severity]}`}>
        {severity.toUpperCase()}
      </span>
    );
  };

  const activeAlerts = alerts.filter(alert => !alert.acknowledged);
  const acknowledgedAlerts = alerts.filter(alert => alert.acknowledged);

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-slate-900">Alert Management</h2>
          <div className="flex items-center gap-4">
            <div className="text-sm">
              <span className="text-red-600 font-semibold">{activeAlerts.length}</span>
              <span className="text-slate-600"> active alerts</span>
            </div>
            <div className="text-sm">
              <span className="text-green-600 font-semibold">{acknowledgedAlerts.length}</span>
              <span className="text-slate-600"> acknowledged</span>
            </div>
          </div>
        </div>

        {/* Active Alerts */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2 text-red-500" />
            Active Alerts ({activeAlerts.length})
          </h3>
          
          {activeAlerts.length === 0 ? (
            <div className="bg-white p-8 rounded-lg border text-center">
              <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto mb-3" />
              <p className="text-slate-600">No active alerts - all systems normal</p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeAlerts.map((alert) => {
                const Icon = getAlertIcon(alert.type);
                return (
                  <div
                    key={alert.id}
                    className={`border-l-4 p-4 rounded-lg shadow-sm ${getAlertColor(alert.severity)}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Icon className={`h-5 w-5 ${getAlertTextColor(alert.severity)}`} />
                          <span className="font-semibold text-slate-900">{alert.type}</span>
                          {getSeverityBadge(alert.severity)}
                        </div>
                        
                        <p className={`mb-3 ${getAlertTextColor(alert.severity)}`}>
                          {alert.message}
                        </p>
                        
                        <div className="flex items-center gap-4 text-sm text-slate-600">
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {new Date(alert.timestamp).toLocaleString()}
                          </div>
                          {alert.position && (
                            <div>
                              Position: {alert.position.lat.toFixed(4)}°N, {alert.position.lon.toFixed(4)}°E
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <button
                        onClick={() => onAcknowledge(alert.id)}
                        className="bg-slate-600 hover:bg-slate-700 text-white px-4 py-2 rounded font-medium flex items-center"
                      >
                        <CheckCircle2 className="h-4 w-4 mr-2" />
                        Acknowledge
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Recent Acknowledged Alerts */}
        {acknowledgedAlerts.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
              <CheckCircle2 className="h-5 w-5 mr-2 text-green-500" />
              Recently Acknowledged ({acknowledgedAlerts.length})
            </h3>
            
            <div className="space-y-3">
              {acknowledgedAlerts.slice(0, 5).map((alert) => {
                const Icon = getAlertIcon(alert.type);
                return (
                  <div
                    key={alert.id}
                    className="bg-white border p-4 rounded-lg opacity-75"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="h-4 w-4 text-gray-500" />
                      <span className="font-medium text-slate-700">{alert.type}</span>
                      <span className="text-sm text-slate-500">
                        {new Date(alert.timestamp).toLocaleString()}
                      </span>
                      <CheckCircle2 className="h-4 w-4 text-green-500 ml-auto" />
                    </div>
                    <p className="text-sm text-slate-600 mt-1 ml-7">
                      {alert.message}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}