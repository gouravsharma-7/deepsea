import React, { useState, useEffect } from 'react';
import { 
  Anchor, 
  AlertTriangle, 
  Zap, 
  Radio,
  Fuel,
  Users,
  Navigation2
} from 'lucide-react';
import type { Vessel, Alert, Geofence } from '../types';

interface LiveMapProps {
  vessels: Vessel[];
  alerts: Alert[];
  onSOS: (vesselId: string) => void;
}

export default function LiveMap({ vessels, alerts, onSOS }: LiveMapProps) {
  const [selectedVessel, setSelectedVessel] = useState<Vessel | null>(null);
  const [mapCenter, setMapCenter] = useState({ lat: 15.0, lon: 73.0 }); // Arabian Sea
  const [zoom, setZoom] = useState(8);

  // Mock EEZ boundary for Indian waters
  const eezBoundary: Geofence = {
    id: 'indian-eez',
    name: 'Indian Exclusive Economic Zone',
    type: 'EEZ',
    polygon: [
      [68.0, 10.0], [78.0, 10.0], [78.0, 20.0], [68.0, 20.0], [68.0, 10.0]
    ],
    rules: { entry: true, fishing: true, transit: true }
  };

  const getVesselStatusColor = (vessel: Vessel) => {
    switch (vessel.status) {
      case 'sos': return 'bg-red-500';
      case 'warning': return 'bg-orange-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-green-500';
    }
  };

  const getRiskScoreColor = (score: number) => {
    if (score >= 7) return 'text-red-500';
    if (score >= 4) return 'text-orange-500';
    return 'text-green-500';
  };

  return (
    <div className="flex-1 relative">
      {/* Map Container */}
      <div className="h-full bg-gradient-to-br from-blue-900 via-blue-800 to-slate-900 relative overflow-hidden">
        {/* Grid overlay for maritime feel */}
        <div className="absolute inset-0 opacity-10">
          <div className="h-full w-full" 
               style={{
                 backgroundImage: `
                   linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                   linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
                 `,
                 backgroundSize: '50px 50px'
               }}>
          </div>
        </div>

        {/* EEZ Boundary */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="border-2 border-dashed border-orange-400 opacity-50 absolute"
               style={{
                 left: '20%',
                 top: '30%',
                 width: '60%',
                 height: '40%',
                 borderRadius: '8px'
               }}>
          </div>
          <div className="absolute text-orange-400 text-sm font-medium"
               style={{ left: '22%', top: '28%' }}>
            Indian EEZ Boundary
          </div>
        </div>

        {/* Vessels */}
        {vessels.map((vessel, index) => {
          const x = 30 + (index * 15) + (vessel.position.lon - 70) * 10;
          const y = 40 + (15 - vessel.position.lat) * 2;
          
          return (
            <div
              key={vessel.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer"
              style={{ 
                left: `${Math.max(10, Math.min(90, x))}%`, 
                top: `${Math.max(10, Math.min(80, y))}%` 
              }}
              onClick={() => setSelectedVessel(vessel)}
            >
              <div className={`w-6 h-6 rounded-full border-2 border-white shadow-lg ${getVesselStatusColor(vessel)} flex items-center justify-center`}>
                <Anchor className="h-3 w-3 text-white" />
              </div>
              
              {/* Vessel wake/trail */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                <div className="w-16 h-1 bg-white opacity-20 rounded-full transform rotate-45"></div>
              </div>
              
              {/* Vessel label */}
              <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-slate-900 bg-opacity-80 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                {vessel.name}
              </div>
              
              {/* Alert indicator */}
              {vessel.status === 'sos' && (
                <div className="absolute -top-2 -right-2 animate-pulse">
                  <AlertTriangle className="h-5 w-5 text-red-500 fill-current" />
                </div>
              )}
            </div>
          );
        })}

        {/* Weather alerts overlay */}
        <div className="absolute top-4 right-4 bg-slate-900 bg-opacity-80 text-white p-4 rounded-lg">
          <h3 className="font-semibold mb-2 flex items-center">
            <Zap className="h-4 w-4 mr-2 text-yellow-400" />
            Weather Alerts
          </h3>
          <div className="text-sm space-y-1">
            <div className="text-yellow-400">Gale Warning - 25kt winds expected</div>
            <div className="text-gray-400">Valid until: 18:00 UTC</div>
          </div>
        </div>

        {/* Emergency SOS Button */}
        <div className="absolute bottom-6 right-6">
          <button
            onClick={() => selectedVessel && onSOS(selectedVessel.id)}
            className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-full font-semibold shadow-lg transform transition-all hover:scale-105 flex items-center"
            disabled={!selectedVessel}
          >
            <AlertTriangle className="h-5 w-5 mr-2" />
            EMERGENCY SOS
          </button>
        </div>
      </div>

      {/* Vessel Details Panel */}
      {selectedVessel && (
        <div className="absolute top-4 left-4 bg-white rounded-lg shadow-xl p-6 w-80">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-slate-900">{selectedVessel.name}</h3>
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${
              selectedVessel.status === 'active' ? 'bg-green-100 text-green-800' :
              selectedVessel.status === 'warning' ? 'bg-orange-100 text-orange-800' :
              selectedVessel.status === 'sos' ? 'bg-red-100 text-red-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              {selectedVessel.status.toUpperCase()}
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-slate-600">MMSI:</span>
              <span className="font-mono">{selectedVessel.mmsi}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Call Sign:</span>
              <span className="font-mono">{selectedVessel.callSign}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-slate-600 flex items-center">
                <Navigation2 className="h-4 w-4 mr-1" />
                Position:
              </span>
              <span className="font-mono text-sm">
                {selectedVessel.position.lat.toFixed(4)}°N, {selectedVessel.position.lon.toFixed(4)}°E
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Speed:</span>
              <span>{selectedVessel.position.sog} kts</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Course:</span>
              <span>{selectedVessel.position.cog}° T</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-slate-600 flex items-center">
                <Fuel className="h-4 w-4 mr-1" />
                Fuel:
              </span>
              <span className={selectedVessel.fuel < 20 ? 'text-red-600 font-semibold' : ''}>
                {selectedVessel.fuel}%
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-slate-600 flex items-center">
                <Users className="h-4 w-4 mr-1" />
                Crew:
              </span>
              <span>{selectedVessel.crew}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Risk Score:</span>
              <span className={`font-semibold ${getRiskScoreColor(selectedVessel.riskScore)}`}>
                {selectedVessel.riskScore}/10
              </span>
            </div>
            
            <div className="pt-3 border-t">
              <div className="text-xs text-slate-500 mb-2">Last Update:</div>
              <div className="text-sm font-mono">{new Date(selectedVessel.lastUpdate).toLocaleString()}</div>
            </div>
          </div>
          
          <div className="mt-4 flex gap-2">
            <button className="flex-1 bg-teal-600 hover:bg-teal-700 text-white py-2 px-4 rounded font-medium flex items-center justify-center">
              <Radio className="h-4 w-4 mr-2" />
              Contact
            </button>
            <button 
              onClick={() => onSOS(selectedVessel.id)}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded font-medium flex items-center justify-center"
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              SOS
            </button>
          </div>
        </div>
      )}
    </div>
  );
}