export interface Vessel {
  id: string;
  name: string;
  mmsi: string;
  callSign: string;
  position: {
    lat: number;
    lon: number;
    sog: number; // Speed over ground
    cog: number; // Course over ground
    timestamp: string;
  };
  status: 'active' | 'sos' | 'warning' | 'offline';
  fuel: number; // Percentage
  crew: number;
  lastUpdate: string;
  riskScore: number;
}

export interface Alert {
  id: string;
  vesselId: string;
  type: 'SOS' | 'GEOFENCE' | 'WEATHER' | 'ENGINE' | 'FUEL' | 'MOB';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: string;
  acknowledged: boolean;
  position?: {
    lat: number;
    lon: number;
  };
}

export interface CatchLog {
  id: string;
  vesselId: string;
  species: string;
  weight: number;
  timestamp: string;
  position: {
    lat: number;
    lon: number;
  };
  photo?: string;
  bycatch: boolean;
}

export interface WeatherAlert {
  id: string;
  type: 'storm' | 'gale' | 'fog' | 'ice';
  severity: 'advisory' | 'watch' | 'warning';
  message: string;
  area: {
    lat: number;
    lon: number;
    radius: number; // km
  };
  validFrom: string;
  validTo: string;
}

export interface Geofence {
  id: string;
  name: string;
  type: 'EEZ' | 'MPA' | 'RESTRICTED';
  polygon: [number, number][];
  rules: {
    entry: boolean;
    fishing: boolean;
    transit: boolean;
  };
}