import { useState, useEffect, useCallback } from 'react';
import type { Vessel, Alert, CatchLog } from '../types';

// Mock data generator functions
const generateVessel = (id: string, name: string, mmsi: string): Vessel => ({
  id,
  name,
  mmsi,
  callSign: `V${mmsi.slice(-3)}`,
  position: {
    lat: 15.2993 + (Math.random() - 0.5) * 0.5,
    lon: 74.1240 + (Math.random() - 0.5) * 0.5,
    sog: Math.random() * 15 + 5, // 5-20 knots
    cog: Math.random() * 360,
    timestamp: new Date().toISOString()
  },
  status: Math.random() < 0.1 ? 'warning' : 'active',
  fuel: Math.random() * 100,
  crew: Math.floor(Math.random() * 8) + 4, // 4-12 crew
  lastUpdate: new Date(Date.now() - Math.random() * 300000).toISOString(), // Within last 5 minutes
  riskScore: Math.floor(Math.random() * 10)
});

const generateAlert = (vesselId: string, type: Alert['type']): Alert => ({
  id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
  vesselId,
  type,
  severity: type === 'SOS' ? 'critical' : 
           type === 'GEOFENCE' ? 'high' :
           Math.random() < 0.3 ? 'high' : 
           Math.random() < 0.6 ? 'medium' : 'low',
  message: getAlertMessage(type),
  timestamp: new Date().toISOString(),
  acknowledged: false,
  position: {
    lat: 15.2993 + (Math.random() - 0.5) * 0.5,
    lon: 74.1240 + (Math.random() - 0.5) * 0.5,
  }
});

function getAlertMessage(type: Alert['type']): string {
  const messages = {
    SOS: 'Emergency SOS activated - vessel in distress',
    GEOFENCE: 'Vessel approaching EEZ boundary - course correction required',
    WEATHER: 'Severe weather warning - 30kt winds expected within 2 hours',
    ENGINE: 'Engine temperature anomaly detected',
    FUEL: 'Low fuel alert - 15% remaining',
    MOB: 'Man overboard alert - emergency response required'
  };
  return messages[type];
}

const generateCatch = (vesselId: string): CatchLog => {
  const species = [
    'Tuna (Yellowfin)', 'Tuna (Skipjack)', 'Marlin (Blue)', 'Mahi Mahi', 
    'Wahoo', 'Kingfish', 'Sailfish'
  ];
  
  return {
    id: `catch-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    vesselId,
    species: species[Math.floor(Math.random() * species.length)],
    weight: Math.random() * 50 + 5, // 5-55 kg
    timestamp: new Date(Date.now() - Math.random() * 86400000 * 7).toISOString(), // Within last week
    position: {
      lat: 15.2993 + (Math.random() - 0.5) * 0.5,
      lon: 74.1240 + (Math.random() - 0.5) * 0.5,
    },
    bycatch: Math.random() < 0.08 // 8% bycatch rate
  };
};

export function useSeaGuardian() {
  const [vessels, setVessels] = useState<Vessel[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [catches, setCatches] = useState<CatchLog[]>([]);
  const [isOnline, setIsOnline] = useState(true);

  // Initialize data
  useEffect(() => {
    const initialVessels = [
      generateVessel('vessel-001', 'Deep Blue', '123456789'),
      generateVessel('vessel-002', 'Ocean Hunter', '234567890'),
      generateVessel('vessel-003', 'Sea Breeze', '345678901'),
      generateVessel('vessel-004', 'Wave Rider', '456789012'),
    ];
    
    setVessels(initialVessels);
    
    // Generate some initial alerts
    const initialAlerts = [
      generateAlert('vessel-002', 'GEOFENCE'),
      generateAlert('vessel-003', 'WEATHER'),
      generateAlert('vessel-001', 'FUEL'),
    ];
    setAlerts(initialAlerts);

    // Generate some catch history
    const initialCatches: CatchLog[] = [];
    for (let i = 0; i < 25; i++) {
      const vesselId = initialVessels[Math.floor(Math.random() * initialVessels.length)].id;
      initialCatches.push(generateCatch(vesselId));
    }
    setCatches(initialCatches);
  }, []);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setVessels(prev => prev.map(vessel => ({
        ...vessel,
        position: {
          ...vessel.position,
          lat: Math.max(14.5, Math.min(16.0, vessel.position.lat + (Math.random() - 0.5) * 0.01)),
          lon: Math.max(73.5, Math.min(75.0, vessel.position.lon + (Math.random() - 0.5) * 0.01)),
          sog: Math.max(0, vessel.position.sog + (Math.random() - 0.5) * 2),
          cog: (vessel.position.cog + (Math.random() - 0.5) * 10) % 360,
          timestamp: new Date().toISOString()
        },
        fuel: Math.max(0, vessel.fuel - Math.random() * 0.1),
        lastUpdate: new Date().toISOString(),
        riskScore: Math.max(0, Math.min(10, vessel.riskScore + (Math.random() - 0.5) * 2))
      })));

      // Occasionally generate new alerts
      if (Math.random() < 0.05) { // 5% chance every update
        const vessel = vessels[Math.floor(Math.random() * vessels.length)];
        if (vessel) {
          const alertTypes: Alert['type'][] = ['WEATHER', 'ENGINE', 'FUEL'];
          const newAlert = generateAlert(vessel.id, alertTypes[Math.floor(Math.random() * alertTypes.length)]);
          setAlerts(prev => [newAlert, ...prev].slice(0, 50)); // Keep last 50 alerts
        }
      }
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, [vessels]);

  // Simulate network connectivity
  useEffect(() => {
    const connectivityInterval = setInterval(() => {
      setIsOnline(Math.random() > 0.05); // 95% uptime
    }, 10000);

    return () => clearInterval(connectivityInterval);
  }, []);

  const triggerSOS = useCallback((vesselId: string) => {
    const vessel = vessels.find(v => v.id === vesselId);
    if (!vessel) return;

    // Update vessel status
    setVessels(prev => prev.map(v => 
      v.id === vesselId ? { ...v, status: 'sos' } : v
    ));

    // Create SOS alert
    const sosAlert = generateAlert(vesselId, 'SOS');
    setAlerts(prev => [sosAlert, ...prev]);

    // Simulate emergency broadcast
    console.log(`🚨 SOS ALERT: ${vessel.name} (${vessel.mmsi}) has triggered emergency distress signal!`);
    console.log(`Position: ${vessel.position.lat.toFixed(4)}°N, ${vessel.position.lon.toFixed(4)}°E`);
    console.log(`Fuel: ${vessel.fuel.toFixed(1)}% | Crew: ${vessel.crew}`);
    
    // Auto-clear SOS status after 30 seconds for demo
    setTimeout(() => {
      setVessels(prev => prev.map(v => 
        v.id === vesselId ? { ...v, status: 'active' } : v
      ));
    }, 30000);
  }, [vessels]);

  const acknowledgeAlert = useCallback((alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, acknowledged: true } : alert
    ));
  }, []);

  const addCatch = useCallback((catchData: Omit<CatchLog, 'id'>) => {
    const newCatch: CatchLog = {
      ...catchData,
      id: `catch-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    };
    setCatches(prev => [newCatch, ...prev]);
  }, []);

  return {
    vessels,
    alerts,
    catches,
    isOnline,
    triggerSOS,
    acknowledgeAlert,
    addCatch
  };
}